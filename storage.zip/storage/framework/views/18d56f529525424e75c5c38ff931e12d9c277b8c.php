<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-12 text-center prod_title" style="background-image: url(../storage/app/public/uploads/img/sidetop-img/<?php echo e($timage); ?>);">
               <h2 class="mb-2 mt-2"> <?php echo e($series_name); ?> </h2>
         </div>
      </div>
      <div class="row e-series">
         <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 text-center hide-mobile">
            <img src="<?php echo e(url('storage/app/public/uploads/img/sidetop-img/'.$simage)); ?>" class="img-responsive" />
         </div>
         <div class="col-12 col-sm-12 col-md-10 col-lg-10 col-xl-10 text-center">
         <div class="row">
            <nav aria-label="breadcrumb">
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?php echo e($series_name); ?></li>
               </ol>
            </nav>
         </div>
            <div class="row">
               <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e(url('/product/'.$series_id.'/'.$value->sku)); ?>" class="col-6 col-sm-4 col-md-4 col-lg-3 col-xl-3  hover-effect container-hover">
               <div class="white-bg">
                  <img src="<?php echo e(url('storage/app/public/uploads/img/'.$series_image.'/'. $value->thumb_img)); ?>" class="img-responsive image white-bg-img" />
                  </div>
                  <h6 class="mb-2 mt-2 show_one_line">  <?php echo e($value->book_title); ?> </h6>
                  
                  <h6 class="mb-4"> <span>₹ <?php echo e($value->actual_price); ?></span></h6>

                  
               </a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div> 
      </div> 
   </div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\subra-gift\resources\views/pages/single-series-book.blade.php ENDPATH**/ ?>