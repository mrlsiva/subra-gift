<?php $__env->startSection('content'); ?>

<?php if($offlineUser): ?>

    <div class="row" style="min-height: 300px">

        <div class="col-12">

            

            <link rel="stylesheet" href="<?php echo e(url('/resources/fonts/material-icon/css/material-design-iconic-font.min.css')); ?>">



            <link rel="stylesheet" href="<?php echo e(url('/resources/css/login.css')); ?>">



            <section class="signup">

                <div class="container">

                    <div class="signup-content">

                        <div class="signup-form">

                            <h2 class="form-title">Reset your password</h2>

                            <form method="POST" action="<?php echo e(route('update.password')); ?>" class="register-form" id="register-form">

                                    <?php echo csrf_field(); ?>



                                    <div class="form-group">

                                        <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>

                                        <input id="name" type="text" class="<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" placeholder="Your Name" value="<?php echo e($offlineUser->name); ?>" required autocomplete="name" autofocus>

                                    </div>

                                    <div class="form-group">

                                        <label for="email"><i class="zmdi zmdi-email"></i></label>

                                        <input id="email" type="email" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($offlineUser->email); ?>"placeholder="Your Email" required autocomplete="email">

                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>

                                            <span class="invalid-feedback" role="alert">

                                                <strong><?php echo e($message); ?></strong>

                                            </span>

                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                    </div>

                                    <div class="form-group">

                                        <label for="old_password"><i class="zmdi zmdi-lock"></i></label>

                                        <input id="old_password" type="password" placeholder="Old Password" name="old_password" required>

                                    </div>

                                    <div class="form-group">

                                        <label for="password"><i class="zmdi zmdi-lock"></i></label>

                                        <input id="password" type="password" placeholder="New Password" class="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>

                                            <span class="invalid-feedback" role="alert">

                                                <strong><?php echo e($message); ?></strong>

                                            </span>

                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                    </div>



                                    <div class="form-group">

                                        <label for="password-confirm"><i class="zmdi zmdi-lock-outline"></i></label>

                                        <input id="password-confirm" placeholder="Repeat new password" type="password" name="password_confirmation" required autocomplete="new-password">

                                    </div>



                                    <div class="form-group mb-0">

                                        <div class="col-md-6 offset-md-4">

                                            <button type="submit" class="btn e-series-book">

                                                Update Password

                                            </button>

                                        </div>

                                    </div>

                            </form>

                        </div>

                        <div class="signup-image">

                            <figure><img src="<?php echo e(url('/resources/images/registration.png')); ?>" alt="sing up image"></figure>

                        </div>

                    </div>

                </div>

            </section>

        </div>

    </div> 

<?php else: ?> 

    <div class="">

        <?php echo $__env->make('includes.carousal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
     <div class="container">
        <div class="row slider_title mt-4">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mt-4 bg-small-line text-left"> <h2 class=""> Our Personalized Products </h2> </div>
        </div>
    <div class="row mt-2">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-sm-6 col-md-4 col-lg-3 col-xl-3 mt-4">
                <div class="product-block">
                 <span class="onsale">Sale!</span>
                 <div class="product-transition">
                 <div class="product-image">
                 <img src="storage/app/public/uploads/img/<?php echo e($value->series_table_name); ?>/<?php echo e($value->series_table_name); ?>.png" class="backup_picture"></div>
                 <a href="series/<?php echo e($value->series_table_name); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"></a></div>
                 <div class="product-caption">
                 <h3 class="woocommerce-loop-product__title">
                 <a href="series/<?php echo e($value->series_table_name); ?>"><?php echo e($value->series_name); ?></a></h3>
                 <div class="short-description"><?php echo e($value->series_desc); ?></div> 
                 <a href="series/<?php echo e($value->series_table_name); ?>"  class="button product_type_simple">
                     View More...
                 </a> 
                 </div></div>
                </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="row mt-4">

        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

            <img class='img-fluid' src="<?php echo e(url('/resources/images/8-1.jpg')); ?>">

        </div>

    </div>
    </div>

    <div class="container mb-5">

    <div class="row slider_title mb-2">

        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mt-4 bg-small-line  text-left"> <h2 class=""> Launch Sale Offer </h2> </div>

    </div>

    <div class="row">

        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 mt-2">

            <img class='img-fluid' src="<?php echo e(url('/resources/images/mr.jpeg?v1')); ?>">

        </div>

        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 mt-2">

            <img class='img-fluid' src="<?php echo e(url('/resources/images/3.jpg?v1')); ?>">

        </div>

    </div>

    </div>

<?php endif; ?>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="resources/js/slick.js" type="text/javascript" charset="utf-8"></script>
    <script>
        $(document).ready(function()
        {
            $(".backup_picture").on("error", function(){
                $(this).attr('src', 'storage/app/public/uploads/img/mug/mug.png');
            });
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\subra-gift\resources\views/welcome.blade.php ENDPATH**/ ?>