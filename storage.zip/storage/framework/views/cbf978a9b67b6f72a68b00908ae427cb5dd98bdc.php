<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
   <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div id="app">
      
        <header class="row">
       <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </header>
        <main class="mt-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <header class="">
       <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </header>
    </div>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\subra-gift\resources\views/layouts/app.blade.php ENDPATH**/ ?>